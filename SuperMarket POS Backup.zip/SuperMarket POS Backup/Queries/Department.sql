-- Department table
CREATE TABLE Department (
    DepartmentID INT PRIMARY KEY, 
    DepartmentName VARCHAR(100) NOT NULL UNIQUE 
);
