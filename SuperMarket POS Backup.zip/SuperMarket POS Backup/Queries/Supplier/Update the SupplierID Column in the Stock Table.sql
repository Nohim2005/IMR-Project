UPDATE Stock
SET SupplierID = S.SupplierID
FROM Stock ST
JOIN Suppliers S
ON ST.Supplier = S.SupplierName;
