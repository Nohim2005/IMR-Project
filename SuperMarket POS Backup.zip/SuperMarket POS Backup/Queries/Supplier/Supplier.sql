-- Create Suppliers table
CREATE TABLE Suppliers (
    SupplierID INT IDENTITY(1,1) PRIMARY KEY,
    SupplierName NVARCHAR(255) NOT NULL UNIQUE,
    ContactInfo NVARCHAR(255) NULL
);

INSERT INTO Suppliers (SupplierName)
SELECT DISTINCT Supplier
FROM Stock
WHERE Supplier NOT IN (SELECT SupplierName FROM Suppliers);

ALTER TABLE Stock
ADD SupplierID INT;

