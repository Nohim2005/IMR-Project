UPDATE Suppliers
SET ContactInfo = '+94 0771234567'
WHERE SupplierName = 'CleanUp Supplies Co.';

UPDATE Suppliers
SET ContactInfo = '+94 0772345678'
WHERE SupplierName = 'FarmFresh Butter Co.';

UPDATE Suppliers
SET ContactInfo = '+94 0773456789'
WHERE SupplierName = 'Fizzy Drinks Co.';

UPDATE Suppliers
SET ContactInfo = '+94 0774567890'
WHERE SupplierName = 'Fresh Dairy Supplies Co.';

UPDATE Suppliers
SET ContactInfo = '+94 0775678901'
WHERE SupplierName = 'Golden Flour Mills';

UPDATE Suppliers
SET ContactInfo = '+94 0776789012'
WHERE SupplierName = 'GrainSuppliers Pvt.';

UPDATE Suppliers
SET ContactInfo = '+94 0777890123'
WHERE SupplierName = 'HomeCare Essentials';

UPDATE Suppliers
SET ContactInfo = '+94 0778901234'
WHERE SupplierName = 'Kandos Co.';

UPDATE Suppliers
SET ContactInfo = '+94 0779012345'
WHERE SupplierName = 'Laundry Solutions Pvt.';

UPDATE Suppliers
SET ContactInfo = '+94 0770123456'
WHERE SupplierName = 'Pop Delight';

UPDATE Suppliers
SET ContactInfo = '+94 0771234568'
WHERE SupplierName = 'Quality Cheese Ltd.';

UPDATE Suppliers
SET ContactInfo = '+94 0772345679'
WHERE SupplierName = 'Ranchip Ltd.';

UPDATE Suppliers
SET ContactInfo = '+94 0773456780'
WHERE SupplierName = 'Scan Water Distributors';

UPDATE Suppliers
SET ContactInfo = '+94 0774567891'
WHERE SupplierName = 'Sun Crush Beverages';

UPDATE Suppliers
SET ContactInfo = '+94 0775678902'
WHERE SupplierName = 'Sweet Crystals Ltd.';
