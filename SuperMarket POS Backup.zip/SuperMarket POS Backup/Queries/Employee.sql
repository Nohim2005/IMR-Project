-- Create the Employee table
CREATE TABLE Employee (
    EmployeeID INT PRIMARY KEY, -- Primary Key
    FirstName VARCHAR(50) NOT NULL, -- Not Null constraint
    LastName VARCHAR(50) NOT NULL, -- Not Null constraint
    Email VARCHAR(100) UNIQUE NOT NULL, -- Unique and Not Null constraint
    PhoneNumber VARCHAR(15),
    HireDate DATE NOT NULL, -- Not Null constraint
    JobID VARCHAR(10) NOT NULL, -- Not Null constraint
    Salary DECIMAL(10, 2) CHECK (Salary > 0), -- Check constraint for positive salary
    ManagerID INT,
    DepartmentID INT,
    CONSTRAINT fk_Manager FOREIGN KEY (ManagerID) REFERENCES Employee(EmployeeID), 
    CONSTRAINT fk_Department FOREIGN KEY (DepartmentID) REFERENCES Department(DepartmentID) 
);


