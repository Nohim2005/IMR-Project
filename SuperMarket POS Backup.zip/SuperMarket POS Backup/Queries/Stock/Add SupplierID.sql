ALTER TABLE Stock
ADD SupplierID INT;


