USE SupermarketPOS;

INSERT INTO Customer (FirstName, LastName, PhoneNumber, Email, LoyaltyPoints)
VALUES ('Nohim', 'Senanayake', '0775663128', 'nohim.senanayake@example.com', 100);
