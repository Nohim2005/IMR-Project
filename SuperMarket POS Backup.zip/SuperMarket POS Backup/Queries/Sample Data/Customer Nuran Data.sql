USE SupermarketPOS;

INSERT INTO Customer (FirstName, LastName, PhoneNumber, Email, LoyaltyPoints,DateJoined) 
VALUES ('Nuran', 'Athukorala', '0774565428', 'nuran.athukorala@example.com', 100, '2024-12-01');
