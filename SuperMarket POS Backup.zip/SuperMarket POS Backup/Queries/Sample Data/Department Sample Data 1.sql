INSERT INTO Department (DepartmentID, DepartmentName)
VALUES (2, 'Human Resources');
