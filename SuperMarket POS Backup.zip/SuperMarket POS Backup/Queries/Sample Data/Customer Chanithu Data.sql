USE SupermarketPOS;

INSERT INTO Customer (FirstName, LastName, PhoneNumber, Email, LoyaltyPoints,DateJoined) 
VALUES ('Chanithu', 'Rithmal', '0773438648', 'chanithu.rithmal@example.com', 100, '2024-11-25');
