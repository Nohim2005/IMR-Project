USE SupermarketPOS;

INSERT INTO Customer (FirstName, LastName, PhoneNumber, Email, LoyaltyPoints,DateJoined) 
VALUES ('Yasiru', 'Haputhanthiri', '0776578653', 'yasiru.haputhanthiri@example.com', 135, '2024-12-02');