--Constraint for FirstName to only allow alphabetic characters
ALTER TABLE [SupermarketPOS].[dbo].[Customer]
ADD CONSTRAINT CHK_FirstName_Alphabetic
    CHECK ([FirstName] LIKE '%[A-Za-z]%');

-- Constraint for LastName to only allow alphabetic characters
ALTER TABLE [SupermarketPOS].[dbo].[Customer]
ADD CONSTRAINT CHK_LastName_Alphabetic
    CHECK ([LastName] LIKE '%[A-Za-z]%');

-- Make phonenumber unique
ALTER TABLE [SupermarketPOS].[dbo].[Customer]
ADD CONSTRAINT UQ_PhoneNumber UNIQUE ([PhoneNumber]);

-- Allow only numeric values to phonenumber.
ALTER TABLE [SupermarketPOS].[dbo].[Customer]
ADD CONSTRAINT CHK_PhoneNumber_Numeric
    CHECK ([PhoneNumber] LIKE '[0-9]%');

-- Make Email unique
ALTER TABLE [SupermarketPOS].[dbo].[Customer]
ADD CONSTRAINT UQ_Email UNIQUE ([Email]);

-- Validate Emial Structure
ALTER TABLE [SupermarketPOS].[dbo].[Customer]
ADD CONSTRAINT CHK_Email_Format
    CHECK ([Email] LIKE '%@%.%');

-- Prevent Loyalty Points Negative
ALTER TABLE [SupermarketPOS].[dbo].[Customer]
ADD CONSTRAINT CHK_LoyaltyPoints_NonNegative
    CHECK ([LoyaltyPoints] >= 0);

-- Prevent furture dates in date Joined
ALTER TABLE [SupermarketPOS].[dbo].[Customer]
ADD CONSTRAINT CHK_DateJoined_Valid
    CHECK ([DateJoined] <= GETDATE());
