ALTER TRIGGER trg_Customer_Validation
ON [SupermarketPOS].[dbo].[Customer]
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Validate FirstName
    IF EXISTS (
        SELECT 1
        FROM inserted
        WHERE [FirstName] NOT LIKE '%[A-Za-z]%'
    )
    BEGIN
        RAISERROR ('FirstName must only contain alphabetic characters.', 16, 1);
        ROLLBACK TRANSACTION;
        RETURN;
    END;

    -- Validate LastName
    IF EXISTS (
        SELECT 1
        FROM inserted
        WHERE [LastName] NOT LIKE '%[A-Za-z]%'
    )
    BEGIN
        RAISERROR ('LastName must only contain alphabetic characters.', 16, 1);
        ROLLBACK TRANSACTION;
        RETURN;
    END;

    -- Validate PhoneNumber format
    IF EXISTS (
        SELECT 1
        FROM inserted
        WHERE [PhoneNumber] NOT LIKE '[0-9]%'
    )
    BEGIN
        RAISERROR ('PhoneNumber must contain only numeric characters.', 16, 1);
        ROLLBACK TRANSACTION;
        RETURN;
    END;

    -- Validate Email format
    IF EXISTS (
        SELECT 1
        FROM inserted
        WHERE [Email] NOT LIKE '%@%.%'
    )
    BEGIN
        RAISERROR ('Email format is invalid. It must contain "@" and ".".', 16, 1);
        ROLLBACK TRANSACTION;
        RETURN;
    END;

    -- Validate LoyaltyPoints
    IF EXISTS (
        SELECT 1
        FROM inserted
        WHERE [LoyaltyPoints] < 0
    )
    BEGIN
        RAISERROR ('LoyaltyPoints must be non-negative.', 16, 1);
        ROLLBACK TRANSACTION;
        RETURN;
    END;

    -- Validate DateJoined
    IF EXISTS (
        SELECT 1
        FROM inserted
        WHERE [DateJoined] > GETDATE()
    )
    BEGIN
        RAISERROR ('DateJoined cannot be in the future.', 16, 1);
        ROLLBACK TRANSACTION;
        RETURN;
    END;
END;

