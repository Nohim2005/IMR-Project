INSERT INTO Employee (EmployeeID, FirstName, LastName, Email, PhoneNumber, HireDate, JobID, Salary, ManagerID, DepartmentID)
VALUES (1, 'John', 'Doe', 'john.doe@example.com', '123-456-7890', '2025-01-01', 'DEV', 50000, NULL, 1);



