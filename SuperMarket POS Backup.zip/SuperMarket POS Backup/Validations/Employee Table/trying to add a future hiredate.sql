-- Add a check constraint to ensure hire date is not in the future
ALTER TABLE Employee
ADD CONSTRAINT chk_HireDate CHECK (HireDate <= GETDATE());
