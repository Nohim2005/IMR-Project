-- Insert a record with a unique ProductName and Category
INSERT INTO Stock (ProductName, Category, UnitPrice, CostPrice, QuantityInStock, ReorderLevel)
VALUES ('Pepsi', 'Beverages', 12.00, 9.00, 150, 20); -- Should succeed

-- Attempt to insert a duplicate ProductName within the same Category
INSERT INTO Stock (ProductName, Category, UnitPrice, CostPrice, QuantityInStock, ReorderLevel)
VALUES ('Pepsi', 'Beverages', 11.00, 8.50, 120, 15); -- Should fail
