-- Stock Table Constraints

-- Prevent NULL Values

ALTER TABLE Stock
ALTER COLUMN ProductName NVARCHAR(255) NOT NULL;
ALTER TABLE Stock
ALTER COLUMN Category NVARCHAR(100) NOT NULL;
ALTER TABLE Stock
ALTER COLUMN UnitPrice DECIMAL(10, 2) NOT NULL;
ALTER TABLE Stock
ALTER COLUMN CostPrice DECIMAL(10, 2) NOT NULL;
ALTER TABLE Stock
ALTER COLUMN QuantityInStock INT NOT NULL;
ALTER TABLE Stock
ALTER COLUMN ReorderLevel INT NOT NULL;

-- Enusre every product has a unique name within the same category

ALTER TABLE Stock
ADD CONSTRAINT UQ_ProductName_Category UNIQUE (ProductName, Category);

-- Set default value in QuantityInStock to 0
ALTER TABLE Stock
ADD CONSTRAINT DF_QuantityInStock DEFAULT 0 FOR QuantityInStock;

-- Set default value of LastRestocked to the current date
ALTER TABLE Stock
ADD CONSTRAINT DF_LastRestocked DEFAULT GETDATE() FOR LastRestocked;
