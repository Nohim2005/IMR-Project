-- Attempt to insert a record with NULL values in NOT NULL columns
INSERT INTO Stock (ProductName, Category, UnitPrice, CostPrice, QuantityInStock, ReorderLevel)
VALUES (NULL, 'Beverages', 10.00, 8.00, 100, 10); 

INSERT INTO Stock (ProductName, Category, UnitPrice, CostPrice, QuantityInStock, ReorderLevel)
VALUES ('Coke', NULL, 10.00, 8.00, 100, 10); 

INSERT INTO Stock (ProductName, Category, UnitPrice, CostPrice, QuantityInStock, ReorderLevel)
VALUES ('Coke', 'Beverages', NULL, 8.00, 100, 10); 

INSERT INTO Stock (ProductName, Category, UnitPrice, CostPrice, QuantityInStock, ReorderLevel)
VALUES ('Coke', 'Beverages', 10.00, NULL, 100, 10); 

INSERT INTO Stock (ProductName, Category, UnitPrice, CostPrice, QuantityInStock, ReorderLevel)
VALUES ('Coke', 'Beverages', 10.00, 8.00, NULL, 10); 

INSERT INTO Stock (ProductName, Category, UnitPrice, CostPrice, QuantityInStock, ReorderLevel)
VALUES ('Coke', 'Beverages', 10.00, 8.00, 100, NULL);
