-- Insert a record without specifying QuantityInStock
INSERT INTO Stock (ProductName, Category, UnitPrice, CostPrice, ReorderLevel)
VALUES ('Fanta', 'Beverages', 15.00, 12.00, 20);

-- Verify the default value
SELECT ProductName, QuantityInStock FROM Stock WHERE ProductName = 'Fanta';
