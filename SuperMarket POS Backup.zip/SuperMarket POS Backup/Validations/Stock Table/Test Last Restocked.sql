-- Insert a record without specifying LastRestocked
INSERT INTO Stock (ProductName, Category, UnitPrice, CostPrice, QuantityInStock, ReorderLevel)
VALUES ('Mountain Dew', 'Beverages', 14.00, 11.00, 50, 25);

-- Verify the default value
SELECT ProductName, LastRestocked FROM Stock WHERE ProductName = 'Mountain Dew';
