-- TotalAmount should be positive

ALTER TABLE Sales
ADD CONSTRAINT chk_TotalAmount_Positive CHECK (TotalAmount > 0);

-- A Sale cannot be in the future
ALTER TABLE Sales
ADD CONSTRAINT chk_SaleDateTime_NotFuture CHECK (SaleDateTime <= GETDATE());

