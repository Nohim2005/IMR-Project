INSERT INTO Sales (SaleDateTime, CustomerID, TotalAmount)
VALUES (GETDATE(), 1, 100.00); -- Valid

INSERT INTO Sales (SaleDateTime, CustomerID, TotalAmount)
VALUES (GETDATE(), 1, 0.00); -- Will fail due to the constraint
