-- Add test data to the Sales table
INSERT INTO Sales (SaleDateTime, CustomerID, TotalAmount)
VALUES ('2024-12-01 12:00:00', 1, 500.00),
       ('2024-12-01 13:00:00', 2, 300.00),
       ('2024-12-02 10:00:00', 3, 200.00);

SELECT dbo.fn_TotalRevenueByDate('2024-12-01') AS TotalRevenue;
