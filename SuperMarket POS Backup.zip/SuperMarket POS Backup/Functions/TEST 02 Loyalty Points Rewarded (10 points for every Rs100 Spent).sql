SELECT SaleID, TotalAmount, dbo.GetLoyaltyPoints(TotalAmount) AS LoyaltyPointsRewarded
FROM Sales;
