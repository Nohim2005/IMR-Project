-- Calculate total revenue of the day
CREATE FUNCTION dbo.fn_TotalRevenueByDate (@SaleDate DATE)
RETURNS DECIMAL(10, 2)
AS
BEGIN
    DECLARE @TotalRevenue DECIMAL(10, 2);
    SELECT @TotalRevenue = SUM(TotalAmount)
    FROM Sales
    WHERE CAST(SaleDateTime AS DATE) = @SaleDate;

    RETURN ISNULL(@TotalRevenue, 0);
END;
