CREATE FUNCTION dbo.GetLoyaltyPoints(@TotalAmount DECIMAL(10, 2))
RETURNS INT
AS
BEGIN
    RETURN CAST(@TotalAmount / 100 AS INT) * 10; -- 10 points for every 100 spent
END;
