SELECT dbo.GetLoyaltyPoints(250.00) AS LoyaltyPointsRewarded; -- Expected result: 20
SELECT dbo.GetLoyaltyPoints(1050.00) AS LoyaltyPointsRewarded; -- Expected result: 100
SELECT dbo.GetLoyaltyPoints(45.00) AS LoyaltyPointsRewarded; -- Expected result: 0
