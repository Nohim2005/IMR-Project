CREATE VIEW CustomerLoyaltySummary AS
SELECT 
    Customer.CustomerID,
    Customer.FirstName + ' ' + Customer.LastName AS FullName,
    Customer.Email,
    Customer.LoyaltyPoints,
    ISNULL(SUM(Sales.TotalAmount), 0) AS TotalSpent
FROM Customer
LEFT JOIN Sales ON Customer.CustomerID = Sales.CustomerID
GROUP BY 
    Customer.CustomerID, 
    Customer.FirstName, 
    Customer.LastName, 
    Customer.Email, 
    Customer.LoyaltyPoints;
