SELECT * FROM CustomerLoyaltySummary;
