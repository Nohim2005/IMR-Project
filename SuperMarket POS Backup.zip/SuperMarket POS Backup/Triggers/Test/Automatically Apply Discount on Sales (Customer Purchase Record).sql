INSERT INTO Sales (SaleDateTime, CustomerID, TotalAmount)
VALUES ('2024-11-29', 1, 0.00); 

