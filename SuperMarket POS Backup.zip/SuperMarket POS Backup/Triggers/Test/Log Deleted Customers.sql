DELETE FROM Customer WHERE CustomerID = 5;
