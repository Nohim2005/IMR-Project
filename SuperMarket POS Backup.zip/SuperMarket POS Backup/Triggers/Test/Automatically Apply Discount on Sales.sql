INSERT INTO SalesDetails (SaleID, ProductID, QuantitySold, SellingPrice, DiscountApplied, TotalPrice)
VALUES (1, 1, 3, 150.00, 0.00, 0.00);
