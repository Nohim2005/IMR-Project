UPDATE Stock
SET QuantityInStock = -5
WHERE ProductID = 1;
