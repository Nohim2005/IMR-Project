-- Create an AFTER trigger to enforce additional logic if needed
CREATE TRIGGER trg_CheckHireDate
ON Employee
AFTER INSERT, UPDATE
AS
BEGIN
    IF EXISTS (SELECT 1 FROM inserted WHERE HireDate > GETDATE())
    BEGIN
        RAISERROR ('Hire date cannot be in the future.', 16, 1);
        ROLLBACK TRANSACTION;
    END
END;
